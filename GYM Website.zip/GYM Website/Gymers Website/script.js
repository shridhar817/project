
    document.addEventListener('DOMContentLoaded', () => {
        // --- DOM Element Selection ---
        const allPageContents = document.querySelectorAll('.page-content');
        const allNavLinks = document.querySelectorAll('.nav-link');
        const mobileToggle = document.getElementById('mobile-toggle');
        const mobileCloseToggle = document.getElementById('mobile-close-toggle');
        const mobileNavMenu = document.getElementById('mobile-nav-menu');
        const mobileNavOverlay = document.getElementById('mobile-nav-overlay');

        // --- Page Navigation Logic ---
        const showPage = (pageId) => {
            // First, hide all page content sections.
            allPageContents.forEach(page => {
                page.style.display = 'none';
            });

            // Find and display the target page based on the 'pageId' argument.
            const targetPage = document.getElementById(`${pageId}-page`);
            if (targetPage) {
                targetPage.style.display = 'block';
                window.scrollTo(0, 0); // Scrolls the user to the top of the new page.
            } else {
                // If the requested page doesn't exist, show the home page as a fallback.
                document.getElementById('home-page').style.display = 'block';
            }

            // --- Update Active Nav Link ---
            // This part updates the visual indicator on the navigation links for both desktop and mobile.
            allNavLinks.forEach(link => {
                link.classList.remove('active'); // Remove 'active' class from all links.
                // Add 'active' class to the link corresponding to the currently visible page.
                if (link.getAttribute('data-page') === pageId) {
                    link.classList.add('active');
                }
            });

            // --- Close Mobile Menu on Navigation ---
            // If the mobile menu is open, this will close it automatically after a link is clicked.
            if(mobileNavMenu.classList.contains('active')) {
                closeMobileMenu(); // Use the dedicated close function
            }
        };

        // --- Mobile Menu Toggle Logic ---
        // This section controls the opening and closing of the mobile navigation menu.
        const openMobileMenu = () => {
            mobileNavMenu.classList.add('active'); // Shows the menu.
            mobileNavOverlay.classList.add('active'); // Shows the dark overlay behind the menu.
        };

        const closeMobileMenu = () => {
            mobileNavMenu.classList.remove('active'); // Hides the menu.
            mobileNavOverlay.classList.remove('active'); // Hides the overlay.
        };

        // Attaching the functions to the corresponding button clicks.
        mobileToggle.addEventListener('click', openMobileMenu);
        mobileCloseToggle.addEventListener('click', closeMobileMenu);
        mobileNavOverlay.addEventListener('click', closeMobileMenu); // Allows closing the menu by clicking the overlay.

        // --- Event Listeners for Page Switching (Navigation & CTA Buttons) ---
        // This listener targets all .nav-link elements, any .btn with an href starting with '#', and the logo.
        document.querySelectorAll('a.nav-link, a.btn[href^="#"], a.logo[href^="#"]').forEach(link => {
            link.addEventListener('click', (e) => {
                let pageId = link.getAttribute('data-page'); // Try to get pageId from data-page attribute first.

                if (!pageId) {
                    // If data-page is not present, try to extract pageId from href.
                    const href = link.getAttribute('href');
                    if (href && href.startsWith('#')) {
                        // Remove '#' from href. If the ID is 'home-page', convert to 'home'.
                        let potentialPageId = href.substring(1);
                        if (potentialPageId.endsWith('-page')) {
                            pageId = potentialPageId.replace('-page', '');
                        } else {
                            pageId = potentialPageId; // Use directly if it's already just the ID (e.g., 'auth').
                        }
                    }
                }
                
                // If a valid pageId is found and corresponds to an existing page-content div,
                // prevent default link behavior and show the page.
                if (pageId && document.getElementById(`${pageId}-page`)) {
                    e.preventDefault(); // Prevents the default browser action for anchor tags.
                    showPage(pageId);   // Calls the function to switch pages.
                }
                // If pageId is not found or does not correspond to a page-content div,
                // the default action (smooth scrolling if applicable) will proceed.
            });
        });

        // --- Smooth Scrolling for General Anchor Links ---
        // This section handles smooth scrolling for any remaining anchor links (e.g., footer links
        // or internal section links that do not trigger a full page-content switch).
        // It should run after the page-switching logic.
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                // Only execute if the default action hasn't already been prevented by a page-switching handler.
                if (!e.defaultPrevented) {
                    const targetId = this.getAttribute('href').substring(1);
                    const targetElement = document.getElementById(targetId);
                    if (targetElement) {
                        e.preventDefault(); // Prevent default browser action for smooth scroll.
                        targetElement.scrollIntoView({ behavior: 'smooth' });
                    }
                }
            });
        });

        // --- Initial Page Load ---
        // This ensures that the 'home' page is displayed by default when the website first loads.
        showPage('home');

        // --- Auth Form Toggle (Login/Sign Up) ---
        const authToggleButtons = document.querySelectorAll('.auth-btn');
        const authForms = document.querySelectorAll('.auth-form');

        authToggleButtons.forEach(button => {
            button.addEventListener('click', () => {
                const formToShow = button.getAttribute('data-form');

                authForms.forEach(form => {
                    form.classList.remove('active');
                });
                authToggleButtons.forEach(btn => {
                    btn.classList.remove('active');
                });

                document.getElementById(`${formToShow}-form`).classList.add('active');
                button.classList.add('active');
            });
        });

        // --- Gallery Filter Logic ---
        const filterButtons = document.querySelectorAll('.filter-btn');
        const galleryItems = document.querySelectorAll('.gallery-item');

        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                const filter = button.getAttribute('data-filter');

                filterButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');

                galleryItems.forEach(item => {
                    if (filter === 'all' || item.getAttribute('data-category') === filter) {
                        item.style.display = 'block'; // Adjust if your CSS uses 'flex', 'grid' etc.
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
        });

        // --- Classes Schedule Logic ---
        const dayButtons = document.querySelectorAll('.day-btn');
        const daySchedules = document.querySelectorAll('.day-schedule');

        dayButtons.forEach(button => {
            button.addEventListener('click', () => {
                const dayToShow = button.getAttribute('data-day');

                daySchedules.forEach(schedule => {
                    schedule.classList.remove('active');
                    schedule.style.display = 'none'; // Ensure elements are properly hidden
                });
                dayButtons.forEach(btn => {
                    btn.classList.remove('active');
                });

                const targetSchedule = document.getElementById(dayToShow);
                if (targetSchedule) {
                    targetSchedule.classList.add('active');
                    targetSchedule.style.display = 'block'; // Adjust if your CSS uses 'flex', 'grid' etc.
                }
                button.classList.add('active');
            });
        });

        const readMoreButtons = document.querySelectorAll('.blog-card .read-more');
        const blogPopupOverlay = document.getElementById('blog-popup-overlay');
        const closeButtons = document.querySelectorAll('.blog-popup-box .close-btn');
        const blogPopupBoxes = document.querySelectorAll('.blog-popup-box');

        // Function to open a specific popup
        function openPopup(blogId) {
            // Hide all popups first
            blogPopupBoxes.forEach(box => {
                box.classList.remove('active');
            });

            // Show the overlay
            blogPopupOverlay.classList.add('active');

            // Show the specific popup
            const targetPopup = document.getElementById(blogId);
            if (targetPopup) {
                targetPopup.classList.add('active');
            }
        }

        // Function to close all popups
        function closeAllPopups() {
            blogPopupOverlay.classList.remove('active');
            blogPopupBoxes.forEach(box => {
                box.classList.remove('active');
            });
        }

        // Event listeners for "Read More" buttons
        readMoreButtons.forEach(button => {
            button.addEventListener('click', function(event) {
                event.preventDefault(); // Prevent default link behavior
                const blogId = this.getAttribute('data-blog-id');
                openPopup(blogId);
            });
        });

        // Event listeners for close buttons within each popup
        closeButtons.forEach(button => {
            button.addEventListener('click', closeAllPopups);
        });

        // Event listener for clicking outside the popup (on the overlay)
        blogPopupOverlay.addEventListener('click', function(event) {
            // If the click target is the overlay itself, close the popup
            if (event.target === blogPopupOverlay) {
                closeAllPopups();
            }
        });

        // Optional: Close popup with ESC key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape' && blogPopupOverlay.classList.contains('active')) {
                closeAllPopups();
            }
        });

    // --- Login Form Validation ---
        const loginForm = document.getElementById('loginForm'); // Get the login form by its ID
        const loginEmailInput = document.getElementById('loginEmail'); // Get the email input
        const loginPasswordInput = document.getElementById('loginPassword'); // Get the password input
        const loginMessage = document.getElementById('loginMessage'); // Get the message display area

        // Define your demo credentials
        const demoEmail = 'test@example.com';
        const demoPassword = 'password123';

        if (loginForm) { // Ensure the form exists before adding event listener
            loginForm.addEventListener('submit', (e) => {
                e.preventDefault(); // Prevent default form submission (page reload)

                const enteredEmail = loginEmailInput.value;
                const enteredPassword = loginPasswordInput.value;

                if (enteredEmail === demoEmail && enteredPassword === demoPassword) {
                    loginMessage.style.color = 'green';
                    loginMessage.textContent = 'Login successful! Redirecting...';
                    // In a real application, you would redirect the user or perform other actions here
                    setTimeout(() => {
                        // Example: redirect to home page or a dashboard
                        // window.location.href = '#home'; // If you want to use your existing SPA logic
                        // showPage('home'); // If you want to use your existing showPage function
                        // Or just clear the message
                        loginMessage.textContent = '';
                        loginEmailInput.value = '';
                        loginPasswordInput.value = '';
                    }, 1500);
                } else {
                    loginMessage.style.color = 'red';
                    loginMessage.textContent = 'Invalid email or password. Please try again.';
                }
            });
        }

        
        // Display Monday's schedule by default on load
        if (document.getElementById('monday')) {
            document.getElementById('monday').style.display = 'block';
        }
    });