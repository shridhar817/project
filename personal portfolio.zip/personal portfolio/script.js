const projects = [
  {
    title: "Personal Portfolio Website",
    description: "A responsive and modern portfolio to showcase my projects and skills.",
    tech: ["HTML", "CSS", "JavaScript"],
    github: "https://github.com/yourusername/portfolio",
    demo: "https://yourportfolio.com",
    image: "Screenshot 2025-07-07 112530.png"
  },
  {
    title: "webpage for a gym ",
    description: "A full-stack webpage for a gym with authentication and real-time updates.",
    tech: ["HTML", "CSS", "JavaScript", "Django", "MongoDB"],
    github: "https://github.com/yourusername/task-manager",
    demo: "https://taskmanager.com",
    image: "Screenshot 2025-07-07 112015.png"
  },
  {
  title: "weather telling webpage ",
    description: "A full-stack webpage which tell the weather report according to city.",
    tech: ["HTML", "CSS", "JavaScript", ],
    github: "https://github.com/yourusername/task-manager",
    demo: "https://taskmanager.com",
    image: "Screenshot 2025-07-07 112854.png"
  },
  {
    title: "e commerce webpage",
    description: "A full-stack webpage for an e-commerce platform with product listings and a shopping cart.",
    tech: ["HTML", "CSS", "JavaScript","Django","python","SQLite"],
    github: "https://github.com/yourusername/task-manager",
    demo: "https://taskmanager.com",
    image: "Screenshot 2025-07-07 114651.png"
  }
  // Add more projects as needed
];

const container = document.getElementById('projects-container');
projects.forEach(project => {
  const div = document.createElement('div');
  div.className = 'project-card';
  div.innerHTML = `
    <img src="${project.image}" alt="${project.title}" class="project-image"/>
    <h3>${project.title}</h3>
    <p>${project.description}</p>
    <p><strong>Tech:</strong> ${project.tech.join(', ')}</p>
    <a href="${project.github}" target="_blank">GitHub</a> | 
    <a href="${project.demo}" target="_blank">Live Demo</a>
  `;
  container.appendChild(div);
});